﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using MySql.Data.MySqlClient;

// Definición del espacio de nombres para la aplicación de Buscaminas.
namespace Buscaminas
{
    // Clase principal de la ventana del juego de Buscaminas.
    public partial class MainWindow : Window
    {
        // Constante para definir el tamaño del tablero del juego.
        private const int Size = 10;
        // Arreglo bidimensional para almacenar los botones que representan las celdas del tablero.
        private Button[,] buttons = new Button[Size, Size];
        // Arreglo bidimensional para representar el campo de minas (-1 representa una mina).
        private int[,] mineField = new int[Size, Size];
        // Variable para llevar la puntuación del jugador.
        private int score = 0;
        // Variable para almacenar el nombre del jugador.
        private string playerName = "";

        // Constructor de la clase MainWindow.
        public MainWindow()
        {
            InitializeComponent(); // Inicializa los componentes de la interfaz gráfica.
            AskForPlayerName(); // Solicita al jugador que ingrese su nombre.
            InitializeGame(); // Inicia la configuración inicial del juego.
        }

        // Método para solicitar el nombre del jugador.
        private void AskForPlayerName()
        {
            // Muestra un cuadro de diálogo para que el jugador ingrese su nombre. Si no ingresa un nombre, se asigna "Jugador Anónimo".
            playerName = Microsoft.VisualBasic.Interaction.InputBox("Por favor, ingrese su nombre:", "Nombre de jugador", "", -1, -1);
            if (string.IsNullOrEmpty(playerName))
            {
                playerName = "Jugador Anónimo";
            }
        }

        // Método para inicializar el juego.
        private void InitializeGame()
        {
            int mines = AskForMines(); // Solicita al jugador el número de minas.
            PlaceMines(mines); // Coloca las minas en el tablero.
            CalculateMines(); // Calcula el número de minas adyacentes para cada celda.
            CreateButtons(); // Crea los botones que representan las celdas del tablero.
        }

        // Método para solicitar al jugador el número de minas.
        private int AskForMines()
        {
            // Muestra un cuadro de diálogo solicitando el número de minas. Por defecto sugiere 10.
            string input = Microsoft.VisualBasic.Interaction.InputBox("¿Cuántas minas deseas?", "Minas", "10", -1, -1);
            // Intenta convertir la entrada en un número entero. Si falla, se usa el valor por defecto de 10 minas.
            if (!int.TryParse(input, out int mines) || mines < 1 || mines > (Size * Size - 1))
            {
                MessageBox.Show("Número inválido de minas. Se usarán 10 minas por defecto.");
                mines = 10;
            }
            return mines;
        }

        // Método para colocar las minas en el tablero de manera aleatoria.
        private void PlaceMines(int mines)
        {
            Random rand = new Random();
            for (int i = 0; i < mines; i++)
            {
                int row, col;
                do
                {
                    // Genera posiciones aleatorias hasta encontrar una que no tenga ya una mina.
                    row = rand.Next(Size);
                    col = rand.Next(Size);
                } while (mineField[row, col] == -1);
                mineField[row, col] = -1; // Coloca una mina en la posición generada.
            }
        }

        // Método para calcular el número de minas adyacentes para cada celda del tablero.
        private void CalculateMines()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int col = 0; col < Size; col++)
                {
                    if (mineField[row, col] == -1) continue; // Si la celda tiene una mina, la salta.

                    int minesCount = 0;
                    // Revisa las celdas adyacentes para contar cuántas minas hay alrededor.
                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            int newRow = row + i;
                            int newCol = col + j;
                            // Asegura que no se salga del tablero y cuenta si hay una mina.
                            if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size && mineField[newRow, newCol] == -1)
                            {
                                minesCount++;
                            }
                        }
                    }
                    mineField[row, col] = minesCount; // Asigna el número de minas adyacentes a la celda.
                }
            }
        }

        // Método para crear los botones que representarán las celdas del tablero en la interfaz de usuario.
        private void CreateButtons()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int col = 0; col < Size; col++)
                {
                    Button button = new Button
                    {
                        Margin = new Thickness(0), // Sin margen para que los botones estén juntos.
                        Tag = $"{row},{col}" // Almacena la posición del botón como etiqueta para su fácil identificación.
                    };
                    button.Click += Button_Click; // Asigna el manejador de evento para el clic izquierdo.
                    button.MouseRightButtonDown += Button_MouseRightButtonDown; // Asigna el manejador de evento para el clic derecho.
                    buttonsGrid.Children.Add(button); // Añade el botón al grid de la interfaz.
                    buttons[row, col] = button; // Almacena el botón en el arreglo para su posterior referencia.
                }
            }
        }

        // Manejador de eventos para el clic en un botón (celda).
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button; // Obtiene el botón que fue clickeado.
            string tag = button.Tag.ToString(); // Obtiene la posición del botón desde su etiqueta.
            int row = int.Parse(tag.Split(',')[0]); // Extrae la fila de la posición.
            int col = int.Parse(tag.Split(',')[1]); // Extrae la columna de la posición.

            // Comprueba si la celda clickeada contiene una mina.
            if (mineField[row, col] == -1)
            {
                RevealBomb(button); // Revela la mina y termina el juego.
                MessageBox.Show($"Juego terminado. Puntuación final: {score}", "Fin del juego", MessageBoxButton.OK, MessageBoxImage.Information);
                // Aquí podría implementarse una funcionalidad para reiniciar el juego.
            }
            else
            {
                RevealCell(row, col); // Revela la celda si no contiene una mina.
            }
        }

        // Manejador de eventos para el clic derecho en un botón (celda).
        private void Button_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Button button = sender as Button; // Obtiene el botón que recibió el clic derecho.
            if (button.IsEnabled)
            {
                if (button.Content is Image)
                {
                    button.Content = null; // Si ya tenía una bandera, la quita.
                }
                else
                {
                    Image flagImage = new Image
                    {
                        Source = new BitmapImage(new Uri(@"C:\Users\Feruz\source\repos\Buscaminas\Buscaminas\images\flag.png")) // Establece la imagen de la bandera.
                    };
                    button.Content = flagImage; // Coloca una bandera en la celda.
                }
            }
            e.Handled = true; // Previene la propagación del evento para evitar que se active el evento de clic izquierdo.
        }

        // Método para revelar el contenido de una celda.
        private void RevealCell(int row, int col)
        {
            Button button = buttons[row, col]; // Obtiene el botón correspondiente a la celda.
            if (button == null || !button.IsEnabled || button.Content is Image) return; // Si ya está revelado o marcado, no hace nada.

            button.IsEnabled = false; // Deshabilita el botón para evitar más clics.
            button.Opacity = 0.5; // Hace el botón semi-transparente para indicar que está revelado.

            if (mineField[row, col] > 0)
            {
                button.Content = mineField[row, col].ToString(); // Muestra el número de minas adyacentes si es mayor que cero.
            }

            score += 10; // Aumenta la puntuación.
            scoreTextBlock.Text = $"Puntuación: {score}"; // Actualiza la puntuación en la interfaz.

            // Si la celda no tiene minas adyacentes, intenta revelar las celdas adyacentes.
            if (mineField[row, col] == 0)
            {
                for (int i = -1; i <= 1; i++)
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        if (i == 0 && j == 0) continue; // Evita la celda actual.
                        int newRow = row + i;
                        int newCol = col + j;
                        // Verifica que la nueva posición esté dentro del tablero y revela la celda.
                        if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size)
                        {
                            RevealCell(newRow, newCol);
                        }
                    }
                }
            }
        }

        // Método para revelar una mina y terminar el juego.
        private void RevealBomb(Button button)
        {
            Image bombImage = new Image
            {
                Source = new BitmapImage(new Uri(@"C:\Users\Feruz\source\repos\Buscaminas\Buscaminas\images\bomb.png")) // Establece la imagen de la bomba.
            };
            button.Content = bombImage; // Muestra la imagen de la bomba en la celda.

            DatabaseHelper.SavePlayerScore(playerName, score); // Guarda la puntuación del jugador en la base de datos.
        }
    }

    // Clase auxiliar para trabajar con la base de datos.
    public class DatabaseHelper
    {
        // Cadena de conexión a la base de datos MySQL.
        private const string ConnectionString = "Server=localhost;Database=buscaminas;User ID=root;Password=;";

        // Método estático para guardar la puntuación del jugador en la base de datos.
        public static void SavePlayerScore(string playerName, int score)
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                connection.Open(); // Abre la conexión a la base de datos.

                using (MySqlCommand command = new MySqlCommand())
                {
                    command.Connection = connection;
                    // Prepara la sentencia SQL para insertar el nombre del jugador y su puntuación.
                    command.CommandText = "INSERT INTO players (Name, Score) VALUES (@Name, @Score)";
                    command.Parameters.AddWithValue("@Name", playerName);
                    command.Parameters.AddWithValue("@Score", score);

                    try
                    {
                        command.ExecuteNonQuery(); // Ejecuta la sentencia SQL.
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}"); // Maneja cualquier error que pueda ocurrir.
                    }
                }
            }
        }
    }
}
